dividend = int(input("Enter the dividend:"))
divisor = int(input("Enter the divisor:"))
quotient = dividend // divisor
remainder = dividend % divisor
print(f'{quotient} is the quotient  of the numbers.')
print(f'{remainder} is the remainder of the number')