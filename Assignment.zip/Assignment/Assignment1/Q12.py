import math

r = float(input("Enter radius of sphere: "))
volume = (4/3) * math.pi * (r ** 3)
print("Volume of Sphere:", volume)
