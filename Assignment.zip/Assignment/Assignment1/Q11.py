import math

r = float(input("Enter radius of circle: "))
area = math.pi * (r ** 2)
circumference = 2 * math.pi * r
print("Area of Circle:", area)
print("Circumference of Circle:", circumference)
