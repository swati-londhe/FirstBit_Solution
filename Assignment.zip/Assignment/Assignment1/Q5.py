P = float(input("Enter the principal:"))
T = int(input("Enter the Time:"))
R = float(input("Enter the Rate:"))
amount = P * (1 + R/100) ** T
CI = amount - P
print(f'{CI} is the compound interest.')