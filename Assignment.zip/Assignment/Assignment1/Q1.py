m1 = int(input("Enter the first subject marks:"))
m2 = int(input("Enter the second subject marks:"))
m3 = int(input("Enter the third subject marks:"))
m4 = int(input("Enter the fourth subject marks:"))
m5 = int(input("Enter the fifth subject marks:"))
total = m1 + m2 + m3 + m4 + m5
Percentage = (total/500) * 100
print(f'{Percentage} is the percentage of student.')