p = int(input("Enter the principal:"))
t = int(input("Enter the Time:"))
r = int(input("Enter the rate:"))
SI = (p * t * r) /100
print(f'{SI} is the simple interest.')