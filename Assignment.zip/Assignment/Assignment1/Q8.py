total_days = int(input("Enter the days:"))
year = total_days // 365
remaining_days = total_days % 365
Weeks = remaining_days // 7
Days = remaining_days % 7
print("Convert days into years, weeks,days:",year, Weeks, Days)