angle1 = int(input("Enter the angle1 of the Triangle:"))
angle2 = int(input("Enter the angle2 of the Triangle:"))
third_angle = 180 - (angle1 + angle2)
print(f'{third_angle} is the third angle of the triangle.')