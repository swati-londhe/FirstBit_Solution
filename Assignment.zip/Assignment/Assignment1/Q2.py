l = int(input("Enter the length:"))
b = int(input("Enter the breadth:"))
area = l * b
print(f'{area} is the are of rectangle')