import math

a = float(input("Enter side of equilateral triangle: "))
area = (math.sqrt(3) / 4) * (a ** 2)
print("Area of Equilateral Triangle:", area)
