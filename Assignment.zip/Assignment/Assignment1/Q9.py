base = float(input("Enter the base of triangle:"))
height = float(input("Enter the height of triangle:"))
area = 0.5 * base * height
print("Area of triangle:",area)