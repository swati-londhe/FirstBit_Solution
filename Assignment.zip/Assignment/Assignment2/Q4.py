l = 3.5
b = 9.5
h = 5
base = 10
area_of_triangle = 0.5 * 10 * 5
area_of_rectangle = l * b
print(f'{area_of_triangle} is the area of the triangle.')
print(f'{area_of_rectangle} is the area of the rectangle.')
