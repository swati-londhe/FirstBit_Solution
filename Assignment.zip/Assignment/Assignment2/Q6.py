basic = int(input("Enter the basic salary:"))
da = 0.10 * basic
ta = 0.12 * basic
hra = 0.15 * basic
total_salary = basic + da + ta + hra
print(f'{total_salary} is the total salary of the Employee.')
