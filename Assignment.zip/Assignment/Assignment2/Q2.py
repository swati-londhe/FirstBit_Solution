temp = int(input("Enter the temperture in Celsius:"))
fahernheit = (temp * 9/5) +32
print(" the temperture conversion celsisu to Fahernheit is:",fahernheit)
