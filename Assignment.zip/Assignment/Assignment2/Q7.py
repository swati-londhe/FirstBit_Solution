digit = int(input("Enter the 3 digit number:"))
last = digit % 10
middle = (digit // 10) % 10
first = digit // 100
sum = first + middle + last 
print(f'{sum} is the sum of Three digit number.')