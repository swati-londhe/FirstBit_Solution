cost_price = int(input("Enter the cost price of the book:"))
discount = int(input("Enter the discount of the book in %:"))
Discount = (cost_price * discount)/100
selling_price = cost_price - Discount
print(f'{selling_price} is the  selling price of  the book.')