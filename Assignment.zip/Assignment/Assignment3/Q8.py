import random
userid = "admin"
password = "Pass@123"
Entered_userid = input("Enter the userid:")
Entered_password = input("Enter the Password:")
if(Entered_userid.lower() == userid and Entered_password == password):
    captcha = random.randint(1000,9999)
    print("Captcha is:",captcha)
    enteredd_captcha = int(input("Enter the captcha:"))
    if(enteredd_captcha == captcha):
        print("Login Successfully")
    else:
        print("Login falied")
else:
    print("invalid userid and password.")