a = int(input("Enter the First side of triangle:"))
b = int(input("Enter the second side of Triangle:"))
c = int(input("Enter the third side of Triangle:"))
if (a +b > c) and (a + c > b) and (b + c > a):
    print("Triangle is valid ")
else:
    print("Triangle is invalid")