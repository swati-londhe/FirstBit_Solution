num = int(input("Enter the 3 digit number:"))
if str(num) == str(num)[::-1]:
    print(f'{num} is palindrome')
else:
    print(f'{num} is not Palindrom')