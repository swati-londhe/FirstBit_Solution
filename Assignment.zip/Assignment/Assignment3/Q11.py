ticket_price = float(input("Enter the ticket price per person: "))

# Person 1
age1 = int(input("Enter the age of person 1: "))
if age1 < 12:
    pay1 = ticket_price * 0.7
else:
    if age1 > 59:
        pay1 = ticket_price * 0.5
    else:
        pay1 = ticket_price

# Person 2
age2 = int(input("Enter the age of person 2: "))
if age2 < 12:
    pay2 = ticket_price * 0.7
else:
    if age2 > 59:
        pay2 = ticket_price * 0.5
    else:
        pay2 = ticket_price

# Person 3
age3 = int(input("Enter the age of person 3: "))
if age3 < 12:
    pay3 = ticket_price * 0.7
else:
    if age3 > 59:
        pay3 = ticket_price * 0.5
    else:
        pay3 = ticket_price

# Person 4
age4 = int(input("Enter the age of person 4: "))
if age4 < 12:
    pay4 = ticket_price * 0.7
else:
    if age4 > 59:
        pay4 = ticket_price * 0.5
    else:
        pay4 = ticket_price

# Person 5
age5 = int(input("Enter the age of person 5: "))
if age5 < 12:
    pay5 = ticket_price * 0.7
else:
    if age5 > 59:
        pay5 = ticket_price * 0.5
    else:
        pay5 = ticket_price

# Total
total_amount = pay1 + pay2 + pay3 + pay4 + pay5
print("Total ticket amount for 5 people:", total_amount)
