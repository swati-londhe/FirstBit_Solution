userid = "admin"
password = "Pass@123"
Enter_userid = input("Enter the user id:")
Enter_password = input("Enter the password:")
if(Enter_userid.lower() == userid) and (Enter_password == password):
    print("Login Successfully")
else:
    print("Invalid userid and password.")