gender = (input("Enter the gender:"))
gender= gender.lower()
age = int(input("Enter the Age:"))
if (gender == "male"):
    if (age >= 21):
        print("Eligible for marriage.")
    else:
        print("Not eligible for marriage.")

else:
    if(age > 17):
        print("Eligible for marriage.")

    else:
        print("Not eligible for marriage")
