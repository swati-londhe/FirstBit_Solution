a = int(input("Enter the first side of triangle:"))
b = int(input("Enter the second side of triangle:"))
c = int(input("Enter the third side of triangle:"))
if(a + b > c) and (a + c > b) and(b + c > a):
    if(a == b == c):
        print("This triangle is Equilateral.")
    elif(a == b or b == c or c == a):
        print("This triangle is Isosceles.")
    else:
        print("This triangle is Scalene.")
else:
    print("given sides do not from valid triangle")