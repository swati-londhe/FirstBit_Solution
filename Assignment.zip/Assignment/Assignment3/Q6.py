cost_price = int(input("Enter the cost price:"))
selling_price = int(input("Enter the selling price:"))
if(selling_price > cost_price):
    profit = selling_price - cost_price
    print("profit of this market is:",profit)

elif(selling_price < cost_price):
    loss = cost_price - selling_price
    print("Loss of this market is:",loss)

else:
    print("No Profit No Loss")

