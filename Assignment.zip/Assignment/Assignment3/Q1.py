num = int(input("Enter the number:"))
if(num>=0):
    print(f'{num} is the positive number.')
else:
    print(f'{num} is negative number.')