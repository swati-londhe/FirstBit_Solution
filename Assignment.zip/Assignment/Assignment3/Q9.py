m1 = int(input("Enter the first subject marks:"))
m2 = int(input("Enter the second subject marks:"))
m3 = int(input("Enter the third subject marks:"))
m4 = int(input("Enter the fourth subject marks:"))
m5 = int(input("Enter the fifth subject marks:"))
total = m1 + m2 + m3 + m4 +m5
percentage = total / 5
if(percentage >= 75):
    print("The Student is Distinction.") 
elif(percentage >= 60 and percentage < 75 ):
    print("The Student is First Class.")
elif(percentage >= 50 and percentage < 60):
    print("The Student is Second Class.")
elif(percentage >= 40 and percentage <50):
    print("The Student is pass class.")
else:
    print("The Student is Fail")
