char = input("Enter the alphabet:")
char= char.lower()
vowel =['a','e','i','o','u']
if(char == vowel):
    print(f'{char} is the vowel.')

else:
    print(f'{char} is the consonant.')