while True:
    choice = input("Enter '0 ' to exit or any other key to enter a new bill:").strip()
    if choice == '0':
        print("Exiting, GoodBye!")
        break
    total = 0.0
    count = 0
    print("ENter prices of 5 products:")
    for i in range(5):
        price = float(input(f"Product {i+1} price: "))
        total += price

    gst = total * 0.18
    final_bill = total + gst

    print("\n--- Bill ---")
    print("Subtotal =", total)
    print("GST @18% =", gst)
    print("Final Bill =", final_bill)
    print()