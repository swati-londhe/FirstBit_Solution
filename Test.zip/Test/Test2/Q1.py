year = int(input("Enter a year (0 to exit): "))

while year != 0:  
    if year % 400 == 0:
        print(year, "is a Leap Year")
    elif year % 100 == 0:
        print(year, "is NOT a Leap Year")
    elif year % 4 == 0:
        print(year, "is a Leap Year")
    else:
        print(year, "is NOT a Leap Year")
    
    
    year = int(input("\nEnter a year (0 to exit): "))
