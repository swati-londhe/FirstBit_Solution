while True:
    side = int(input("Enter side length of wall (0 to exit):"))
    if side == 0:
        break
    cost_per_unit = int(input("Enter painting cost per square unit:"))
    area = side * side
    total_area = 4 * area
    total_cost = total_area * cost_per_unit
    print("Total painting Cost = Rs",total_cost)