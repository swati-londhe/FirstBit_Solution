import math
while True:
    r = int(input("Enter radius (0 to stop):"))
    if r == 0:
        break
    L = int(input("Enter the length of rectangle:"))
    B = int(input("Enter breadth of reactangle:"))
    semi_circle = math.pi * r
    rect_perimeter = (2 * B) + L
    total_perimeter = semi_circle + rect_perimeter
    wire_length = total_perimeter * 5
    cost = wire_length * 35
    print("Total fencing cost = rs",round(cost , 2))