num = int(input("Enter the 3 digit number:"))
while(num > 0):
    first_digit = num // 100
    second_digit = (num // 10) % 10
    Third_digit = num % 10
    if(first_digit == 2 * second_digit):
        if (Third_digit == 2 * first_digit):
            print("Yes, you have done it")
        else:
            print("Please try next time.")
    else:
        print("Please try next time.")
    break