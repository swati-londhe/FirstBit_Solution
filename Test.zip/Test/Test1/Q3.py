km = int(input("Enter the distance in Km:"))
meter = km * 1000
centimeters = km * 100000
print("distance in meter:",meter)
print("distance in centimeters:",centimeters)